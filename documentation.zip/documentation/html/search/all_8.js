var searchData=
[
  ['maxrows_0',['maxRows',['../class_confirmer.html#a37dad3f1e783963714c260dc2d2dbc4d',1,'Confirmer']]],
  ['maxtokens_1',['maxTokens',['../class_confirmer.html#a4ebf380385c2cf1c6ac35e853b10e0f4',1,'Confirmer']]]
];
