var searchData=
[
  ['data_0',['Data',['../class_data.html',1,'']]],
  ['doubledata_1',['DoubleData',['../class_double_data.html',1,'DoubleData'],['../class_double_data.html#abf241be92aae077e24402a5593453437',1,'DoubleData::DoubleData()'],['../class_double_data.html#a7577c92838b071e7c2073060b599c4d5',1,'DoubleData::DoubleData(const double value)']]]
];
