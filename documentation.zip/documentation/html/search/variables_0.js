var searchData=
[
  ['type_0',['type',['../class_data.html#ae10a596db6baa817f66cd8769bc19b27',1,'Data']]]
];
