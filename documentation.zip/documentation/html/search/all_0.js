var searchData=
[
  ['biggestdata_0',['biggestData',['../class_confirmer.html#a77f8276f492957967bb6e659d7147be7',1,'Confirmer']]]
];
