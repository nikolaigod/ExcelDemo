var searchData=
[
  ['formuladata_0',['FormulaData',['../class_formula_data.html',1,'FormulaData'],['../class_formula_data.html#a904f237b211214e4226997df644ff89d',1,'FormulaData::FormulaData()'],['../class_formula_data.html#a21ab177a0db8c61d34a0e8aad9272fe5',1,'FormulaData::FormulaData(const int row1, const int col1, const int row2, const int col2, const std::string &amp;operation)'],['../class_formula_data.html#a495b88749c389e6e599a6a2b01a07f13',1,'FormulaData::FormulaData(const double dval1, const double dval2, const std::string &amp;operation)'],['../class_formula_data.html#a59f1c2bcd386eb33c1b3764e0b22d838',1,'FormulaData::FormulaData(const double dval1, const int row1, const int col1, std::string &amp;operation, bool whosFirst)']]]
];
