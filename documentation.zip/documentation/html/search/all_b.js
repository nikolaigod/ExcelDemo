var searchData=
[
  ['table_0',['Table',['../class_table.html',1,'']]],
  ['type_1',['type',['../class_data.html#ae10a596db6baa817f66cd8769bc19b27',1,'Data']]]
];
