var searchData=
[
  ['get_5ftokens_0',['get_tokens',['../class_c_s_v_reader.html#ae48c039490258d4c79bf63dda68e7c0d',1,'CSVReader']]],
  ['getinstance_1',['getInstance',['../class_table.html#a22101ffd96b6a8059cc30dd92cdfb46d',1,'Table']]],
  ['getmaxcols_2',['getMaxCols',['../class_table.html#adc8313d8a70bdeb811dd137a5f4bd386',1,'Table']]],
  ['getmaxrows_3',['getMaxRows',['../class_table.html#acadf531fc433c1c7b222d001fa5639b4',1,'Table']]],
  ['gettable_4',['getTable',['../class_table.html#a1ce5c8bf6ded8a0acadb1ace6d38c2cc',1,'Table']]],
  ['gettype_5',['getType',['../class_data.html#a132da9128fdb020c40af589499ca2ce6',1,'Data::getType()'],['../class_double_data.html#af7c84867df0ee4f93ea004a6c3d9ac14',1,'DoubleData::getType()'],['../class_formula_data.html#ac343e8da820bc506678a4a13f2c4bb18',1,'FormulaData::getType()'],['../class_int_data.html#a32141896d28777435e77605058217111',1,'IntData::getType()'],['../class_string_data.html#a07b287bca2fa746d081235fec006ecc4',1,'StringData::getType()']]],
  ['getval_6',['getVal',['../class_double_data.html#aff1fe28c4e8ffa3a08dade6b06a5fd74',1,'DoubleData::getVal()'],['../class_int_data.html#ab5975b572774710b5c390b1973a712e9',1,'IntData::getVal()'],['../class_string_data.html#a01c60ac10542b83f4fbef60160c91e17',1,'StringData::getVal()']]]
];
