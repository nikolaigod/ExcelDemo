var searchData=
[
  ['data_0',['Data',['../class_data.html',1,'']]],
  ['doubledata_1',['DoubleData',['../class_double_data.html',1,'']]]
];
