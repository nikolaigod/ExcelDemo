var searchData=
[
  ['save_0',['save',['../class_table.html#aa00fdd226fdd44f63f08f099647dddb0',1,'Table']]],
  ['saveas_1',['saveAs',['../class_table.html#ae17fe852a5f9b25b2f395c4ce537b6b5',1,'Table']]],
  ['stringdata_2',['StringData',['../class_string_data.html#a275e75f907efb8b3679688646cdf30e4',1,'StringData::StringData()'],['../class_string_data.html#a5943e82ece401868313da60f732c2f61',1,'StringData::StringData(const std::string &amp;value)']]],
  ['stringify_3',['stringify',['../class_data.html#a92503fa1dfd1dd0cb0696e57c95e4196',1,'Data::stringify()'],['../class_double_data.html#aec645ef82a6af1d5be61ffc68cee9157',1,'DoubleData::stringify()'],['../class_formula_data.html#aefa85299bbcf877726a2c49810e18bb8',1,'FormulaData::stringify()'],['../class_int_data.html#a7319875ec6017506b94a6e88f093ec40',1,'IntData::stringify()'],['../class_string_data.html#a9b51b09a872f885cb29ea88196972c03',1,'StringData::stringify()']]],
  ['stringifyfile_4',['stringifyFile',['../class_data.html#acb4397572f3dd12e66fe716423574ae1',1,'Data::stringifyFile()'],['../class_double_data.html#a9f3b96344a42031d6d4edcdfe90eb62b',1,'DoubleData::stringifyFile()'],['../class_formula_data.html#a0163ea86da9118abbbfbb08d5830393a',1,'FormulaData::stringifyFile()'],['../class_int_data.html#a456384f2dba4b481042239b45f0785d2',1,'IntData::stringifyFile()'],['../class_string_data.html#aa2993e86edb794e0b7e39df37c582182',1,'StringData::stringifyFile()']]]
];
