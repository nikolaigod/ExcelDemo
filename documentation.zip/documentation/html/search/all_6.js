var searchData=
[
  ['has_5fmore_5fdata_0',['has_more_data',['../class_c_s_v_reader.html#aecc3fa5df6c5d1076f01d299940008a7',1,'CSVReader']]]
];
