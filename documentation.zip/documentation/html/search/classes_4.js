var searchData=
[
  ['stringdata_0',['StringData',['../class_string_data.html',1,'']]]
];
