var indexSectionsWithContent =
{
  0: "bcdefghimpst~",
  1: "cdfist",
  2: "bcdefghimps~",
  3: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

